npm install
npx remotion studio src/index.ts
npx remotion render src/index.ts Main out/video.mp4
