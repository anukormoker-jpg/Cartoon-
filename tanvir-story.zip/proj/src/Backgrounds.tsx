import React from 'react';
const INK = '#222';
const st = {stroke: INK, strokeWidth: 3, strokeLinejoin: 'round' as const};

// সাধারণ দোকান: সাইনবোর্ড, তাক+খাতা, কাউন্টার+প্রিন্টার, কাঠের মেঝে
export const Shop: React.FC = () => (
  <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0}}>
    <rect width={1920} height={1080} fill="#F4E3C1" />
    <rect y={840} width={1920} height={240} fill="#C99B66" />
    {[900, 960, 1020, 1060].map((y) => <line key={y} x1={0} x2={1920} y1={y} y2={y} stroke="#B5844F" strokeWidth={3} />)}
    {[0, 1].map((side) => [250, 430].map((y) => {
      const x0 = side ? 1240 : 60;
      return (
        <g key={`${side}${y}`}>
          {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => <rect key={i} x={x0 + 20 + i * 76} y={y - 78 + (i % 3) * 8} width={56} height={78 - (i % 3) * 8} fill={['#EF7C7C', '#7CB7EF', '#F2D06B', '#8FD19E'][i % 4]} {...st} />)}
          <rect x={x0} y={y} width={640} height={18} fill="#8B5E3C" {...st} />
        </g>
      );
    }))}
    <path d="M880 0 V40 M1040 0 V40" stroke={INK} strokeWidth={4} />
    <rect x={760} y={40} width={400} height={100} rx={14} fill="#2F7D6B" {...st} />
    <text x={960} y={110} fontSize={62} fontWeight={700} textAnchor="middle" fill="#fff" stroke="none">স্টেশনারি</text>
    <rect x={800} y={810} width={460} height={270} fill="#A9713F" {...st} />
    <rect x={780} y={780} width={500} height={32} rx={6} fill="#C38A53" {...st} />
    <rect x={900} y={700} width={220} height={80} rx={12} fill="#E7E9EE" {...st} />
    <rect x={930} y={664} width={160} height={42} fill="#fff" {...st} />
    <circle cx={1085} cy={735} r={6} fill="#22C55E" />
    <rect x={1160} y={740} width={80} height={40} fill="#6BA3E8" {...st} /><rect x={1170} y={715} width={60} height={26} fill="#F2D06B" {...st} />
  </svg>
);

// রাস্তা (দিনের শেষ বা সন্ধ্যা) — scroll দিয়ে বিল্ডিং সরবে
export const Street: React.FC<{dusk?: boolean; scroll?: number; t?: number}> = ({dusk, scroll = 0, t = 0}) => {
  const B = [[0, 300, 520], [300, 240, 380], [540, 360, 620], [900, 260, 440], [1160, 340, 560], [1500, 420, 470]];
  const bc = dusk ? ['#4A3F6B', '#5B4B7D'] : ['#E7B58B', '#D9A07A'];
  const buildings = (
    <g>
      {B.map(([x, w, h], i) => (
        <g key={i}>
          <rect x={x} y={820 - h} width={w} height={h} fill={bc[i % 2]} {...st} />
          {Array.from({length: Math.floor(w / 80)}).map((_, c) => Array.from({length: Math.floor(h / 120)}).map((__, r) => (
            <rect key={`${c}-${r}`} x={x + 30 + c * 80} y={820 - h + 30 + r * 120} width={40} height={60} fill={dusk && (c + r) % 2 ? '#FFD166' : '#CFE8FF'} {...st} strokeWidth={2} />
          )))}
        </g>
      ))}
    </g>
  );
  const off = -(scroll % 1920);
  return (
    <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0}}>
      <defs><linearGradient id="sky" x1={0} y1={0} x2={0} y2={1}><stop offset="0" stopColor={dusk ? '#3B2E58' : '#FFD9A8'} /><stop offset="1" stopColor={dusk ? '#F08A5D' : '#FFF0DB'} /></linearGradient></defs>
      <rect width={1920} height={1080} fill="url(#sky)" />
      <circle cx={1500} cy={dusk ? 640 : 300} r={90} fill={dusk ? '#FFB36B' : '#FFE08A'} />
      <g transform={`translate(${off} 0)`}>{buildings}<g transform="translate(1920 0)">{buildings}</g></g>
      <rect y={780} width={1920} height={160} fill="#CFC8BC" {...st} />
      <rect y={940} width={1920} height={140} fill="#6B7280" />
      {Array.from({length: 10}).map((_, i) => <rect key={i} x={(((i * 240 - t * 400) % 2400) + 2400) % 2400 - 240} y={1010} width={120} height={14} rx={6} fill="#F3F4F6" />)}
      <g>
        <rect x={1700} y={420} width={14} height={380} fill="#3F3F46" {...st} /><circle cx={1707} cy={420} r={30} fill={dusk ? '#FFE08A' : '#E5E7EB'} {...st} />
        {dusk && <circle cx={1707} cy={420} r={90} fill="#FFE08A" opacity={0.25} />}
      </g>
    </svg>
  );
};

// মোশন গ্রাফিক্সের ক্লিন ব্যাকগ্রাউন্ড (সফট ভিনিয়েট)
export const MGBg: React.FC<{c1: string; c2: string}> = ({c1, c2}) => (
  <div style={{position: 'absolute', inset: 0, background: `radial-gradient(circle at 50% 45%, ${c1} 0%, ${c1} 50%, ${c2} 100%)`}} />
);
