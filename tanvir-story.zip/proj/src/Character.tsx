import React from 'react';
import {useG} from './time';

export type Pose = {l?: [number, number]; r?: [number, number]};
export type Who = 'tanvir' | 'makbul' | 'polok';
export type Expr = 'neutral' | 'happy' | 'annoyed' | 'surprised' | 'sad' | 'think';
const INK = '#222222';
const S = {stroke: INK, strokeWidth: 2.5, strokeLinejoin: 'round' as const};

const LOOK = {
  tanvir: {skin: '#E8B98F', hair: '#1E1E1E', brow: '#1E1E1E', top: '#A8C8F0', bottom: '#4B4F58', shoe: '#1B1B1B', rolled: true},
  makbul: {skin: '#D8A47A', hair: '#F4F4F4', brow: '#8E8E8E', top: '#FFFFFF', bottom: '#4C8B6F', shoe: '#8A6A4B', rolled: false},
  polok: {skin: '#E6B28C', hair: '#262626', brow: '#262626', top: '#A5D8A0', bottom: '#4A7FD4', shoe: '#8A6A4B', rolled: true},
};

// ছোট প্রপস (হাতের স্থানাঙ্কে আঁকা)
export const NoteProp = () => (<g transform="rotate(-12)"><rect x={-4} y={-30} width={30} height={20} fill="#C8D5B9" {...S} /><text x={11} y={-15} fontSize={11} fontWeight={700} textAnchor="middle" fill={INK}>১০৳</text></g>);
export const PhoneProp = () => (<g><rect x={-9} y={-20} width={18} height={30} rx={3} fill="#2B2B33" {...S} /><rect x={-6} y={-17} width={12} height={22} fill="#93C5FD" /></g>);
export const BookProp = () => (<g><rect x={-18} y={-24} width={36} height={28} rx={3} fill="#C2410C" {...S} /><rect x={-14} y={-20} width={28} height={20} fill="#fff" /></g>);
export const PenProp = () => (<line x1={0} y1={4} x2={14} y2={-20} stroke="#1D4ED8" strokeWidth={4} strokeLinecap="round" />);

const Arm: React.FC<{side: 'l' | 'r'; out: number; bend: number; sleeve: string; skin: string; rolled: boolean; hold?: React.ReactNode; watch?: boolean}> = ({side, out, bend, sleeve, skin, rolled, hold, watch}) => {
  const sg = side === 'l' ? 1 : -1;
  const len = 44;
  return (
    <g transform={`translate(${side === 'l' ? 62 : 138} 140) rotate(${sg * out})`}>
      <rect x={-9.5} y={-8} width={19} height={len + 10} rx={9.5} fill={sleeve} {...S} />
      <g transform={`translate(0 ${len}) rotate(${-sg * bend})`}>
        <rect x={-8} y={-6} width={16} height={len + 6} rx={8} fill={rolled ? skin : sleeve} {...S} />
        {watch && <rect x={-9.5} y={len - 14} width={19} height={10} rx={3} fill="#2B2B33" {...S} />}
        <circle cx={0} cy={len + 4} r={11} fill={skin} {...S} />
        {hold && <g transform={`translate(0 ${len + 4})`}>{hold}</g>}
      </g>
    </g>
  );
};

const Eyes: React.FC<{expr: Expr; blink: boolean; look: number}> = ({expr, blink, look}) => (
  <g>
    {[80, 120].map((x, i) => {
      if (blink || expr === 'happy')
        return <path key={i} d={expr === 'happy' && !blink ? `M${x - 11} 78 Q${x} 63 ${x + 11} 78` : `M${x - 11} 76 Q${x} 82 ${x + 11} 76`} fill="none" stroke={INK} strokeWidth={3.5} strokeLinecap="round" />;
      const ry = expr === 'surprised' ? 16 : expr === 'annoyed' ? 8 : 12;
      const rx = expr === 'surprised' ? 13 : 11;
      return (<g key={i}><ellipse cx={x} cy={74} rx={rx} ry={ry} fill="#fff" {...S} /><circle cx={x + look * 3} cy={74} r={expr === 'surprised' ? 3.5 : 5.5} fill={INK} /></g>);
    })}
  </g>
);
const BROWS: Record<Expr, [string, string]> = {
  neutral: ['M68 56 Q80 51 92 56', 'M108 56 Q120 51 132 56'],
  happy: ['M68 55 Q80 48 92 55', 'M108 55 Q120 48 132 55'],
  annoyed: ['M68 51 L93 61', 'M107 61 L132 51'],
  sad: ['M68 61 L93 52', 'M107 52 L132 61'],
  surprised: ['M68 46 Q80 38 92 46', 'M108 46 Q120 38 132 46'],
  think: ['M68 56 Q80 51 92 56', 'M108 47 Q120 40 132 49'],
};
const Mouth: React.FC<{expr: Expr; m: number}> = ({expr, m}) => {
  if (m === 1) return <ellipse cx={100} cy={105} rx={8} ry={6} fill="#7A2E2E" {...S} />;
  if (m === 2) return <ellipse cx={100} cy={107} rx={11} ry={12} fill="#7A2E2E" {...S} />;
  if (expr === 'happy') return <path d="M82 98 Q100 122 118 98Z" fill="#fff" {...S} />;
  if (expr === 'surprised') return <ellipse cx={100} cy={106} rx={6} ry={8} fill="#7A2E2E" {...S} />;
  const d = {neutral: 'M88 102 Q100 110 112 102', annoyed: 'M88 107 Q100 99 112 107', sad: 'M88 109 Q100 97 112 109', think: 'M90 104 L110 101', happy: ''}[expr];
  return <path d={d} fill="none" stroke={INK} strokeWidth={3.5} strokeLinecap="round" />;
};

export const Character: React.FC<{
  who: Who; x: number; y?: number; scale?: number; flip?: boolean; expr?: Expr; talking?: boolean; mouth?: number;
  pose?: Pose; walk?: boolean; tap?: boolean; sitting?: boolean; tremble?: number; bag?: boolean; watch?: boolean;
  holdL?: React.ReactNode; holdR?: React.ReactNode; look?: number;
}> = ({who, x, y = 930, scale = 2.25, flip, expr = 'neutral', talking, mouth, pose = {}, walk, tap, sitting, tremble = 0, bag, watch, holdL, holdR, look = 0}) => {
  const g = useG();
  const L = LOOK[who];
  const sw = Math.sin(g / 4);
  const float = walk ? Math.abs(sw) * -6 : Math.sin(g / 14) * 4;
  const jx = tremble ? Math.sin(g * 3.1) * tremble : 0;
  const blink = g % 105 < 4;
  const m = mouth !== undefined ? mouth : talking ? [0, 1, 2, 1, 2, 0, 1][Math.floor(g / 4) % 7] : 0;
  const pz = pose as Pose;
  let l: number[] = pz.l || [10, 0], r: number[] = pz.r || [10, 0];
  if (walk) { l = [sw * 28, 6]; r = [-sw * 28, 6]; }
  const legTop = sitting ? 288 : 236;
  const legLen = sitting ? 38 : 84;
  const legRot = (i: number) => (walk ? (i ? -sw : sw) * 24 : tap && i ? Math.sin(g * 0.9) * 10 : 0);
  const kind = who === 'tanvir' ? 'pants' : who === 'makbul' ? 'lungi' : 'shorts';
  return (
    <div style={{position: 'absolute', left: x - 100 * scale, top: y - 340 * scale, width: 200 * scale, height: 340 * scale, transform: `translate(${jx}px, ${float}px) scaleX(${flip ? -1 : 1})`}}>
      <svg viewBox="0 0 200 340" width="100%" height="100%" style={{overflow: 'visible'}}>
        <defs><pattern id="chk" width={16} height={16} patternUnits="userSpaceOnUse"><rect width={16} height={16} fill="#4C8B6F" /><path d="M0 8H16M8 0V16" stroke="#fff" strokeWidth={3} /></pattern></defs>
        {sitting && (<g><rect x={38} y={282} width={124} height={14} rx={5} fill="#A06B3C" {...S} /><rect x={50} y={294} width={10} height={44} fill="#8A5A30" {...S} /><rect x={140} y={294} width={10} height={44} fill="#8A5A30" {...S} /></g>)}
        {/* পা */}
        {[0, 1].map((i) => (
          <g key={i} transform={`translate(${i ? 124 : 76} ${legTop}) rotate(${legRot(i)})`}>
            <rect x={-9} y={0} width={18} height={legLen} rx={9} fill={kind === 'pants' ? L.bottom : L.skin} {...S} />
            {kind === 'shorts' && <rect x={-11} y={-4} width={22} height={38} rx={8} fill={L.bottom} {...S} />}
            <ellipse cx={i ? 4 : -4} cy={legLen + 4} rx={17} ry={9} fill={L.shoe} {...S} />
          </g>
        ))}
        {kind === 'lungi' && <path d={sitting ? 'M50 230 L150 230 L160 292 L40 292Z' : 'M54 232 L146 232 L154 308 L46 308Z'} fill="url(#chk)" {...S} />}
        {/* শরীর */}
        <rect x={52} y={118} width={96} height={who === 'makbul' ? (sitting ? 150 : 162) : 124} rx={28} fill={L.top} {...S} />
        {who === 'tanvir' && (<g><path d="M86 118 L100 138 L114 118Z" fill="#fff" {...S} /><path d="M100 138 V236" stroke={INK} strokeWidth={2} />{[160, 190, 215].map((yy) => <circle key={yy} cx={100} cy={yy} r={2.5} fill={INK} />)}</g>)}
        {who === 'makbul' && (<g><path d="M100 118 V200" stroke={INK} strokeWidth={2.5} />{[140, 165, 190].map((yy) => <circle key={yy} cx={100} cy={yy} r={2.8} fill="#D8D8D8" {...S} />)}</g>)}
        {who === 'polok' && <path d="M84 118 Q100 134 116 118" fill="none" stroke={INK} strokeWidth={2.5} />}
        {bag && (<g><path d="M66 119 L142 236" stroke="#2B2B33" strokeWidth={11} /><rect x={126} y={200} width={56} height={46} rx={8} fill="#2F2F36" {...S} /><path d="M126 214 H182" stroke="#555" strokeWidth={3} /></g>)}
        {/* মাথা */}
        <circle cx={56} cy={78} r={9} fill={L.skin} {...S} /><circle cx={144} cy={78} r={9} fill={L.skin} {...S} />
        <rect x={86} y={108} width={28} height={16} fill={L.skin} {...S} />
        <ellipse cx={100} cy={72} rx={44} ry={48} fill={L.skin} {...S} />
        {who === 'tanvir' && <path d="M56 66 Q54 22 100 22 Q146 22 144 66 Q132 44 100 44 Q68 44 56 66Z" fill={L.hair} {...S} />}
        {who === 'makbul' && <path d="M54 76 Q44 20 100 18 Q156 20 146 76 Q136 40 100 42 Q64 40 54 76Z" fill={L.hair} {...S} />}
        {who === 'polok' && <path d="M56 66 L50 36 L72 48 L80 20 L96 44 L112 18 L122 46 L142 30 L144 66 Q132 46 100 46 Q68 46 56 66Z" fill={L.hair} {...S} />}
        {BROWS[expr].map((d, i) => <path key={i} d={d} fill="none" stroke={L.brow} strokeWidth={4.5} strokeLinecap="round" />)}
        <Eyes expr={expr} blink={blink} look={look} />
        {who === 'tanvir' && [80, 120].map((xx) => <path key={xx} d={`M${xx - 10} 90 Q${xx} 97 ${xx + 10} 90`} fill="none" stroke="#9C6F5B" strokeWidth={2.5} strokeLinecap="round" />)}
        {who === 'makbul' && (<g fill="rgba(255,255,255,0.3)" stroke={INK} strokeWidth={3}><circle cx={80} cy={74} r={17} /><circle cx={120} cy={74} r={17} /><path d="M97 72 H103" fill="none" /></g>)}
        <Mouth expr={expr} m={m} />
        {expr === 'annoyed' && <path d="M152 44 Q158 54 152 58 Q146 54 152 44Z" fill="#93C5FD" {...S} />}
        {/* হাত (মাথার পরে — যাতে মুখের কাছে হাত দেখা যায়) */}
        <Arm side="l" out={l[0]} bend={l[1]} sleeve={L.top} skin={L.skin} rolled={L.rolled} hold={holdL} />
        <Arm side="r" out={r[0]} bend={r[1]} sleeve={L.top} skin={L.skin} rolled={L.rolled} hold={holdR} watch={watch} />
      </svg>
    </div>
  );
};
