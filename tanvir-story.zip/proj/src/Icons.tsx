import React from 'react';
const I = '#222222';
const Svg: React.FC<{s?: number; children: React.ReactNode}> = ({s = 120, children}) => (
  <svg width={s} height={s} viewBox="0 0 64 64" fill="none" stroke={I} strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" style={{overflow: 'visible'}}>{children}</svg>
);
type P = {s?: number};
export const Clock: React.FC<P & {angle?: number}> = ({s, angle = 0}) => (
  <Svg s={s}><circle cx={32} cy={32} r={26} fill="#fff" /><line x1={32} y1={32} x2={44} y2={32} /><g transform={`rotate(${angle} 32 32)`}><line x1={32} y1={32} x2={32} y2={13} /></g></Svg>);
export const Battery: React.FC<P & {level?: number}> = ({s, level = 1}) => (
  <Svg s={s}><rect x={5} y={18} width={47} height={28} rx={5} fill="#fff" /><rect x={52} y={26} width={6} height={12} rx={2} fill={I} />
    <rect x={8} y={21} width={Math.max(1, 41 * level)} height={22} rx={3} fill={level < 0.2 ? '#EF4444' : '#22C55E'} stroke="none" /></Svg>);
export const Mail: React.FC<P> = ({s}) => (<Svg s={s}><rect x={5} y={13} width={54} height={38} rx={5} fill="#fff" /><path d="M5 17 L32 36 L59 17" /></Svg>);
export const Plug: React.FC<P> = ({s}) => (<Svg s={s}><rect x={18} y={26} width={28} height={20} rx={5} fill="#FFD166" /><line x1={26} y1={12} x2={26} y2={26} /><line x1={38} y1={12} x2={38} y2={26} /><path d="M32 46 V58" /></Svg>);
export const Printer: React.FC<P> = ({s}) => (<Svg s={s}><rect x={20} y={8} width={24} height={20} fill="#fff" /><rect x={8} y={26} width={48} height={22} rx={4} fill="#E7E9EE" /><rect x={20} y={42} width={24} height={14} fill="#fff" /><circle cx={48} cy={33} r={2} fill="#22C55E" /></Svg>);
export const Coin: React.FC<P & {label?: string}> = ({s, label = '৳'}) => (
  <Svg s={s}><circle cx={32} cy={32} r={25} fill="#FFD166" /><text x={32} y={43} fontSize={30} fontWeight={700} textAnchor="middle" fill={I} stroke="none">{label}</text></Svg>);
export const Chart: React.FC<P> = ({s}) => (
  <Svg s={s}><path d="M8 8 V56 H58" /><rect x={16} y={36} width={8} height={20} fill="#93C5FD" /><rect x={29} y={28} width={8} height={28} fill="#60A5FA" /><rect x={42} y={18} width={8} height={38} fill="#3B82F6" /><path d="M14 30 L30 18 L42 22 L56 8 M46 8 H56 V18" stroke="#16A34A" strokeWidth={4} /></Svg>);
export const Heart: React.FC<P> = ({s}) => (<Svg s={s}><path d="M32 55 C6 37 10 12 26 16 C30 17 32 20 32 23 C32 20 34 17 38 16 C54 12 58 37 32 55Z" fill="#EF4444" /></Svg>);
export const Cup: React.FC<P> = ({s}) => (
  <Svg s={s}><path d="M10 26 H44 V40 Q44 54 27 54 Q10 54 10 40Z" fill="#fff" /><path d="M12 30 H42 V40 Q42 51 27 51 Q12 51 12 40Z" fill="#C98A4B" stroke="none" /><path d="M44 30 H50 Q57 30 57 37 Q57 44 44 44" /><path d="M20 8 Q15 14 20 19 M30 8 Q25 14 30 19" /></Svg>);
export const Question: React.FC<P & {color?: string}> = ({s, color = '#3B82F6'}) => (<Svg s={s}><text x={32} y={52} fontSize={60} fontWeight={800} textAnchor="middle" fill={color} stroke={I} strokeWidth={1.5}>?</text></Svg>);
export const Star: React.FC<P> = ({s}) => (<Svg s={s}><polygon points="32,6 40,24 59,25 44,38 49,57 32,47 15,57 20,38 5,25 24,24" fill="#FFD166" /></Svg>);
export const Phone: React.FC<P & {missed?: boolean}> = ({s, missed}) => (
  <Svg s={s}><rect x={17} y={5} width={30} height={54} rx={6} fill="#fff" /><rect x={21} y={11} width={22} height={38} rx={2} fill="#DBEAFE" stroke="none" />
    {missed && <><circle cx={32} cy={30} r={9} fill="#EF4444" /><path d="M36 26 L28 34 M28 28 V34 H34" stroke="#fff" /></>}</Svg>);
export const Choco: React.FC<P> = ({s}) => (<Svg s={s}><rect x={10} y={12} width={44} height={40} rx={4} fill="#7B4A2D" /><path d="M10 28 H54 M24 12 V52 M40 12 V52" stroke="#5A3420" /><rect x={10} y={40} width={44} height={12} rx={3} fill="#FFD166" /></Svg>);
export const Book: React.FC<P> = ({s}) => (<Svg s={s}><rect x={9} y={8} width={46} height={48} rx={4} fill="#3B82F6" /><rect x={15} y={13} width={34} height={38} fill="#fff" /><path d="M20 22 H44 M20 30 H44 M20 38 H38" /></Svg>);
export const Sheet: React.FC<P> = ({s}) => (<Svg s={s}><rect x={7} y={9} width={50} height={46} fill="#fff" /><rect x={7} y={9} width={50} height={11} fill="#22C55E" /><path d="M7 31 H57 M7 43 H57 M24 20 V55 M40 20 V55" /></Svg>);
export const Calendar: React.FC<P> = ({s}) => (<Svg s={s}><rect x={7} y={12} width={50} height={44} rx={5} fill="#fff" /><rect x={7} y={12} width={50} height={13} rx={5} fill="#EF4444" /><path d="M20 6 V16 M44 6 V16 M18 36 H22 M30 36 H34 M42 36 H46 M18 46 H22 M30 46 H34" /></Svg>);
export const Bulb: React.FC<P> = ({s}) => (<Svg s={s}><path d="M32 6 C18 6 12 20 20 30 C23 34 24 36 24 42 H40 C40 36 41 34 44 30 C52 20 46 6 32 6Z" fill="#FFD166" /><path d="M25 48 H39 M27 54 H37" /></Svg>);
export const Laptop: React.FC<P> = ({s}) => (<Svg s={s}><rect x={13} y={14} width={38} height={26} rx={3} fill="#fff" /><path d="M5 44 H59 L55 51 H9Z" fill="#CBD5E1" /></Svg>);
export const Monitor: React.FC<P> = ({s}) => (<Svg s={s}><rect x={6} y={9} width={52} height={34} rx={3} fill="#DBEAFE" /><path d="M32 43 V53 M20 54 H44" /></Svg>);
export const Eye: React.FC<P> = ({s}) => (<Svg s={s}><path d="M4 32 Q32 8 60 32 Q32 56 4 32Z" fill="#fff" /><circle cx={32} cy={32} r={9} fill="#3B82F6" /><circle cx={32} cy={32} r={4} fill={I} /></Svg>);
export const Smile: React.FC<P & {mood?: 'happy' | 'sad'}> = ({s, mood = 'happy'}) => (
  <Svg s={s}><circle cx={32} cy={32} r={26} fill="#FFD166" /><circle cx={23} cy={26} r={3} fill={I} /><circle cx={41} cy={26} r={3} fill={I} />
    <path d={mood === 'happy' ? 'M18 38 Q32 54 46 38' : 'M20 48 Q32 36 44 48'} />{mood === 'sad' && <path d="M24 33 Q22 40 25 40" stroke="#3B82F6" />}</Svg>);
export const Cross: React.FC<P> = ({s}) => (<Svg s={s}><circle cx={32} cy={32} r={27} fill="#EF4444" /><path d="M21 21 L43 43 M43 21 L21 43" stroke="#fff" strokeWidth={6} /></Svg>);
export const Check: React.FC<P> = ({s}) => (<Svg s={s}><circle cx={32} cy={32} r={27} fill="#22C55E" /><path d="M19 33 L28 42 L45 22" stroke="#fff" strokeWidth={6} /></Svg>);
export const Friends: React.FC<P> = ({s}) => (
  <Svg s={s}><circle cx={14} cy={22} r={8} fill="#F9A8A8" /><circle cx={32} cy={16} r={9} fill="#A5D8A0" /><circle cx={50} cy={22} r={8} fill="#93C5FD" />
    <path d="M4 52 Q14 34 24 52Z M22 52 Q32 30 42 52Z M40 52 Q50 34 60 52Z" fill="#fff" /></Svg>);
export const ShopIcon: React.FC<P> = ({s}) => (
  <Svg s={s}><path d="M6 24 L12 8 H52 L58 24Z" fill="#EF4444" /><rect x={10} y={24} width={44} height={30} fill="#fff" /><rect x={26} y={34} width={14} height={20} fill="#C98A4B" /><rect x={14} y={30} width={9} height={9} fill="#DBEAFE" /></Svg>);
export const Sun: React.FC<P> = ({s}) => (<Svg s={s}><circle cx={32} cy={32} r={14} fill="#FFB020" /><path d="M32 6 V13 M32 51 V58 M6 32 H13 M51 32 H58 M14 14 L19 19 M45 45 L50 50 M14 50 L19 45 M45 19 L50 14" /></Svg>);
export const Arrow: React.FC<P & {color?: string}> = ({s, color = '#222222'}) => (<Svg s={s}><path d="M8 32 H52 M38 18 L54 32 L38 46" stroke={color} strokeWidth={6} /></Svg>);
