import React from 'react';
import {usePop, useG, ramp} from './time';
import {CAPS, OVERLAYS, FPS, Range} from './data';

export const Fill: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <div style={{position: 'absolute', inset: 0, overflow: 'hidden'}}>{children}</div>
);

// পপ-আপ/ফেড হয়ে আসা এলিমেন্ট (গ্লোবাল সেকেন্ডে a–b)
export const Show: React.FC<{a: number; b: number; style?: React.CSSProperties; anim?: 'pop' | 'up' | 'slide' | 'fade'; children?: React.ReactNode}> = ({a, b, style, anim = 'pop', children}) => {
  const {vis, k, o} = usePop(a, b);
  if (!vis) return null;
  const tr = anim === 'pop' ? `scale(${k})` : anim === 'up' ? `translateY(${(1 - k) * 70}px)` : anim === 'slide' ? `translateX(${(1 - k) * -260}px)` : 'none';
  return <div style={{position: 'absolute', opacity: o, transform: tr, ...style}}>{children}</div>;
};

// আইকন/কনটেন্ট কেন্দ্রবিন্দুতে বসানোর সহজ রূপ
export const At: React.FC<{a: number; b: number; x: number; y: number; s: number; anim?: 'pop' | 'up' | 'slide' | 'fade'; float?: boolean; children?: React.ReactNode}> = ({a, b, x, y, s, anim, float, children}) => {
  const g = useG();
  const dy = float ? Math.sin(g / 10) * 8 : 0;
  return <Show a={a} b={b} anim={anim} style={{left: x - s / 2, top: y - s / 2 + dy, width: s, height: s}}>{children}</Show>;
};

export const Card: React.FC<{w: number; h?: number; bg?: string; children?: React.ReactNode; style?: React.CSSProperties}> = ({w, h, bg = '#fff', children, style}) => (
  <div style={{width: w, height: h, background: bg, border: '5px solid #222', borderRadius: 44, boxShadow: '12px 12px 0 rgba(0,0,0,0.22)', padding: 36, boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 18, textAlign: 'center', ...style}}>{children}</div>
);

// কথার কলআউট বাবল: (x,y) = লেজের ডগা (চরিত্রের মাথার ওপর)
export const Say: React.FC<{d: {r: Range; text: string}; x: number; y: number; dx?: number; w?: number; size?: number}> = ({d, x, y, dx = 0, w = 800, size = 50}) => {
  const {vis, k, o} = usePop(d.r[0], d.r[1]);
  if (!vis) return null;
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-100%) scale(${k})`, transformOrigin: '50% 100%', opacity: o, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
      <div style={{width: w, transform: `translateX(${dx}px)`, background: '#fff', border: '5px solid #222', borderRadius: 40, padding: '22px 34px', fontSize: size, fontWeight: 700, lineHeight: 1.35, color: '#222', textAlign: 'center', boxSizing: 'border-box', boxShadow: '8px 8px 0 rgba(0,0,0,0.2)'}}>{d.text}</div>
      <div style={{width: 40, height: 40, background: '#fff', borderRight: '5px solid #222', borderBottom: '5px solid #222', transform: 'rotate(45deg)', marginTop: -23}} />
    </div>
  );
};

// ভাবনার বাবল
export const Thought: React.FC<{a: number; b: number; x: number; y: number; children?: React.ReactNode}> = ({a, b, x, y, children}) => {
  const {vis, k, o} = usePop(a, b);
  if (!vis) return null;
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-100%) scale(${k})`, transformOrigin: '50% 100%', opacity: o, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
      <div style={{background: '#fff', border: '5px solid #222', borderRadius: 70, padding: '18px 40px', display: 'flex', gap: 20, alignItems: 'center'}}>{children}</div>
      <div style={{width: 34, height: 34, borderRadius: 20, background: '#fff', border: '5px solid #222', marginTop: 8, marginLeft: -30}} />
      <div style={{width: 18, height: 18, borderRadius: 10, background: '#fff', border: '4px solid #222', marginTop: 6, marginLeft: -50}} />
    </div>
  );
};

// ওপরে লোকেশন/সময়ের পিল (ভাসমান ওভারলে)
export const Pill: React.FC<{a: number; b: number; text: string; color?: string; x?: number; y?: number}> = ({a, b, text, color = '#FFD166', x = 60, y = 50}) => (
  <Show a={a} b={b} anim="slide" style={{left: x, top: y}}>
    <div style={{background: color, border: '4px solid #222', borderRadius: 60, padding: '10px 36px', fontSize: 44, fontWeight: 700, color: '#222', boxShadow: '6px 6px 0 rgba(0,0,0,0.2)'}}>{text}</div>
  </Show>
);

// চরিত্রের নামের ব্যাজ
export const Badge: React.FC<{a: number; b: number; x: number; y: number; text: string; color?: string}> = ({a, b, x, y, text, color = '#FF8A5B'}) => {
  const {vis, k, o} = usePop(a, b);
  if (!vis) return null;
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${k})`, opacity: o, background: color, border: '4px solid #222', borderRadius: 50, padding: '8px 30px', fontSize: 42, fontWeight: 700, color: '#222', whiteSpace: 'nowrap', boxShadow: '5px 5px 0 rgba(0,0,0,0.2)'}}>{text}</div>
  );
};

export const Camera: React.FC<{k: number; ox: number; oy: number; max?: number; children?: React.ReactNode}> = ({k, ox, oy, max = 1.3, children}) => (
  <div style={{position: 'absolute', inset: 0, transformOrigin: `${ox}px ${oy}px`, transform: `scale(${1 + (max - 1) * k})`}}>{children}</div>
);

// শ্বাসের ধোঁয়া
export const Puff: React.FC<{a: number; b: number; x: number; y: number}> = ({a, b, x, y}) => (
  <At a={a} b={b} x={x} y={y} s={140} anim="up">
    <svg width={140} height={140} viewBox="0 0 64 64"><g fill="#fff" stroke="#222" strokeWidth={2.5}><circle cx={20} cy={36} r={12} /><circle cx={36} cy={28} r={14} /><circle cx={48} cy={40} r={10} /></g></svg>
  </At>
);

// নিচের ক্যাপশন: কলআউট/কার্ড না থাকলেই, ভাসমান ওভারলে
export const Caption: React.FC = () => {
  const g = useG();
  const t = g / FPS;
  if (OVERLAYS.some(([a, b]) => t >= a && t < b)) return null;
  const c = CAPS.find(([a, b]) => t >= a && t < b);
  if (!c) return null;
  const k = ramp(t, [c[0], c[0] + 0.25], [0, 1]);
  const o = Math.min(k, ramp(t, [c[1] - 0.12, c[1]], [1, 0]));
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 58, display: 'flex', justifyContent: 'center', opacity: o, transform: `translateY(${(1 - k) * 30}px)`}}>
      <div style={{background: 'rgba(20,20,34,0.78)', borderRadius: 26, padding: '10px 44px', fontSize: 58, fontWeight: 600, color: '#fff', whiteSpace: 'nowrap'}}>
        {c[2].split('**').map((p, i) => (i % 2 ? <span key={i} style={{color: '#FFC83D', fontWeight: 700}}>{p}</span> : <span key={i}>{p}</span>))}
      </div>
    </div>
  );
};
