import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';
import {SC, SHAKES, sec, FPS} from './data';
import {StartCtx, ramp, useG} from './time';
import {Caption} from './UI';
import {S1, S2, S3, S4, S5, S6, S7, S8} from './scenes/Scenes';

const {fontFamily} = loadFont('normal', {weights: ['400', '600', '700'], subsets: ['bengali', 'latin']});

// প্রতিটি সিন: ছোট ফেড+জুম ট্রানজিশন ও স্ক্রিন শেক
const Box: React.FC<{children: React.ReactNode}> = ({children}) => {
  const local = useCurrentFrame();
  const t = useG() / FPS;
  const sh = SHAKES.some(([a, b]) => t >= a && t < b);
  const o = ramp(local, [0, 8], [0, 1]);
  const z = ramp(local, [0, 12], [1.05, 1]);
  const dx = sh ? Math.sin(local * 2.7) * 8 : 0;
  return <div style={{position: 'absolute', inset: 0, opacity: o, transform: `translate(${dx}px,0) scale(${z})`}}>{children}</div>;
};

const SCENES = [S1, S2, S3, S4, S5, S6, S7, S8];

export const Main: React.FC = () => (
  <AbsoluteFill style={{fontFamily, background: '#fff'}}>
    <Audio src={staticFile('voice.mp3')} />
    {SCENES.map((S, i) => (
      <Sequence key={i} from={sec(SC[i])} durationInFrames={sec(SC[i + 1]) - sec(SC[i])}>
        <StartCtx.Provider value={sec(SC[i])}><Box><S /></Box></StartCtx.Provider>
      </Sequence>
    ))}
    <Caption />
  </AbsoluteFill>
);
