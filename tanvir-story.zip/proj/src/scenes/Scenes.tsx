import React from 'react';
import {useT, ramp, inR} from '../time';
import {D} from '../data';
import {Character, Pose, NoteProp, PhoneProp, BookProp, PenProp} from '../Character';
import {Shop, Street, MGBg} from '../Backgrounds';
import {Fill, Show, At, Card, Say, Thought, Pill, Badge, Camera, Puff} from '../UI';
import * as Ic from '../Icons';

const TX = 420; // তানভীরের ডিফল্ট অবস্থান (দোকানে)
const MX = 1560; // চাচা মকবুলের অবস্থান
const IDLE: Pose = {l: [12, 5], r: [12, 5]};
const text = (size: number, color = '#222', w = 700): React.CSSProperties => ({fontSize: size, fontWeight: w, color, lineHeight: 1.3});
const Mak: React.FC<{expr?: any; talking?: boolean; pose?: Pose; holdL?: React.ReactNode; holdR?: React.ReactNode}> = (p) => (
  <Character who="makbul" x={MX} scale={2.0} sitting expr={p.expr || 'happy'} talking={p.talking} pose={p.pose || IDLE} holdL={p.holdL} holdR={p.holdR} />
);

// ───────── দৃশ্য ১: দোকানে তাড়া (০–৪.৩) → রাস্তায় রোজকার জীবন ─────────
export const S1: React.FC = () => {
  const t = useT();
  const shop = t < 4.34;
  const tap: Pose = Math.floor(t * 2) % 2 ? {l: [12, 5], r: [40, 100]} : {l: [12, 5], r: [15, 10]};
  return (
    <Fill>
      {shop ? (
        <>
          <Shop />
          <Mak />
          <Character who="tanvir" x={TX} bag watch expr="annoyed" talking={inR(t, 0.1, 4.3)} pose={tap} tap tremble={1.2} />
          <Say d={D.d1} x={TX} y={200} dx={330} w={900} />
          <Badge a={0.3} b={4.3} x={720} y={330} text="তানভীর, ৩০" />
          <Pill a={0.2} b={4.3} text="শহরের মোড়ের দোকান" />
        </>
      ) : (
        <>
          <Street scroll={(t - 4.34) * 160} t={t} />
          <Character who="tanvir" x={760} bag watch expr="annoyed" walk />
          <Badge a={4.5} b={8} x={760} y={175} text="তানভীর" />
          <Pill a={4.5} b={8.5} text="শহর • রোজকার জীবন" color="#A5D8F0" />
          <At a={4.6} b={7.6} x={1250} y={300} s={190} float><Ic.Clock s={190} angle={t * 120} /></At>
          <At a={12.96} b={15.2} x={1220} y={300} s={190} float><Ic.Chart s={190} /></At>
          <At a={14.14} b={15.2} x={1460} y={360} s={170} float><Ic.Coin s={170} /></At>
        </>
      )}
    </Fill>
  );
};

// ───────── দৃশ্য ২: মোশন গ্রাফিক্স (১৫.২–৩৪.৮) ─────────
export const S2: React.FC = () => {
  const t = useT();
  const sunY = ramp(t, [20.9, 25], [250, 520]);
  return (
    <Fill>
      <MGBg c1="#EAF3FF" c2="#B9D3F2" />
      <At a={15.3} b={17.0} x={960} y={470} s={420} float><Ic.Friends s={420} /></At>
      <Show a={17.08} b={20.8} style={{left: 210, top: 330}}>
        <Card w={1500} h={380} style={{flexDirection: 'row', gap: 40}}>
          <Ic.Friends s={240} />
          <div style={{...text(66), maxWidth: 1000}}>“এটা সেটেল হওয়ার বয়স, <span style={{color: '#DC2626'}}>আড্ডা পরে হবে।</span>”</div>
        </Card>
        <Show a={19.6} b={20.8} style={{right: -40, top: -50}}><Ic.Cross s={150} /></Show>
      </Show>
      <At a={20.9} b={25.4} x={300} y={sunY} s={230}><Ic.Sun s={230} /></At>
      <At a={22.88} b={34.8} x={480} y={560} s={280}><Ic.Battery s={280} level={ramp(t, [22.9, 25.2], [0.6, 0.03])} /></At>
      <At a={25.4} b={34.8} x={720} y={560} s={120} anim="slide"><Ic.Arrow s={120} /></At>
      <At a={25.48} b={34.8} x={960} y={560} s={260}><Ic.Mail s={260} /></At>
      <At a={26.4} b={34.8} x={1060} y={450} s={80}><Ic.Cross s={80} /></At>
      <At a={28.82} b={34.8} x={1440} y={560} s={280}><Ic.ShopIcon s={280} /></At>
      <At a={28.8} b={34.8} x={1200} y={560} s={120} anim="slide"><Ic.Arrow s={120} /></At>
      <At a={32.26} b={34.8} x={1330} y={300} s={160} float><Ic.Plug s={160} /></At>
      <At a={33.18} b={34.8} x={1560} y={300} s={160} float><Ic.Printer s={160} /></At>
    </Fill>
  );
};

// ───────── দৃশ্য ৩: দোকানে চাচা মকবুলের পরিচয় (৩৪.৮–৬২.০) ─────────
export const S3: React.FC = () => {
  const t = useT();
  let pose: Pose = IDLE, holdL: React.ReactNode = null;
  if (inR(t, 56.06, 57.0)) pose = {l: [12, 5], r: [40, 115]};
  else if (inR(t, 57.0, 58.74)) { pose = {l: [35, 115], r: [12, 5]}; holdL = <PhoneProp />; }
  const sw = Math.floor(t * 2) % 2 ? 12 : 22;
  if (t >= 58.74) pose = {l: [12, 5], r: [sw, 5]};
  return (
    <Fill>
      <Shop />
      <Mak talking={inR(t, 46.56, 54)} expr="happy" />
      <Character who="tanvir" x={TX} bag watch expr="annoyed" pose={pose} holdL={holdL} tap={t > 58} tremble={t > 58 ? 1.5 : 0} />
      <Pill a={34.9} b={39} text="পুরোনো স্টেশনারি দোকান" />
      <Badge a={36.7} b={41} x={MX} y={250} text="দোকানদার চাচা মকবুল, ৭২" color="#F9C74F" />
      <Say d={D.d2} x={MX} y={280} dx={-330} w={900} size={48} />
      <At a={56.06} b={57.0} x={700} y={330} s={170} float><Ic.Clock s={170} angle={t * 360} /></At>
      <At a={57.0} b={58.74} x={700} y={330} s={170} float><Ic.Phone s={170} /></At>
    </Fill>
  );
};

// ───────── দৃশ্য ৪: পলকের প্রবেশ, চকোলেট (৬২.০–৮৫.৪) ─────────
export const S4: React.FC = () => {
  const t = useT();
  const px = ramp(t, [62.84, 65.0], [-200, 800]);
  const walking = inR(t, 62.84, 65.0);
  const bounce = inR(t, 83.4, 85.4) ? Math.abs(Math.sin(t * 9)) * 30 : 0;
  const pPose: Pose = t >= 65.84 ? {l: [10, 5], r: [35, 85]} : IDLE;
  const tp: Pose = Math.floor(t * 3) % 2 ? {l: IDLE.l, r: [55, 80]} : {l: IDLE.l, r: [55, 68]};
  const mPose: Pose = t >= 70.86 ? {l: [30, 90], r: [30, 90]} : IDLE;
  return (
    <Fill>
      <Shop />
      <Mak talking={inR(t, 80.38, 82.8)} pose={mPose} expr="happy" />
      <Character who="tanvir" x={380} bag watch expr="annoyed" pose={t > 76 ? tp : IDLE} tremble={t > 76 ? 1.5 : 0} />
      <Character who="polok" x={px} y={930 - bounce} scale={1.5} walk={walking} talking={inR(t, 68.3, 70.9) || inR(t, 82.9, 85.4)} expr={t > 82.9 ? 'happy' : 'neutral'} pose={pPose} holdR={t >= 65.84 && t < 70.1 ? <NoteProp /> : null} />
      <Pill a={62.2} b={66} text="একই দোকান • সন্ধ্যা" color="#A5D8F0" />
      <Badge a={64.9} b={68.2} x={800} y={420} text="পলক, ৯" color="#8FD19E" />
      <Say d={D.d3} x={800} y={440} dx={0} w={650} />
      <Say d={D.d4} x={MX} y={280} dx={-330} w={760} />
      <Say d={D.d5} x={800} y={440} dx={120} w={680} />
      <At a={66.7} b={68.3} x={1000} y={560} s={150} float><Ic.Coin s={150} label="১০৳" /></At>
      <At a={69.2} b={72} x={1080} y={560} s={150} float><Ic.Choco s={150} /></At>
      <At a={84.3} b={85.4} x={1260} y={500} s={150} float><Ic.Star s={150} /></At>
      <Puff a={78.88} b={80.3} x={560} y={400} />
    </Fill>
  );
};

// ───────── দৃশ্য ৫: ডায়েরিতে হিসাব (৮৫.৪–১০৪.২) ─────────
export const S5: React.FC = () => {
  const t = useT();
  const wr = Math.floor(t * 4) % 2 ? 100 : 82;
  const writing = t < 101.1;
  const mPose: Pose = writing ? {l: [30, 90], r: [32, wr]} : {l: [12, 5], r: [12, 5]};
  let tPose: Pose = IDLE, holdL: React.ReactNode = null;
  if (inR(t, 85.56, 89)) tPose = {l: IDLE.l, r: [50, 70]};
  if (inR(t, 95.32, 101.1)) { tPose = {l: [35, 115], r: IDLE.r}; holdL = <PhoneProp />; }
  const k = ramp(t, [101.1, 103.4], [0, 1]);
  return (
    <Fill>
      <Camera k={k} ox={MX} oy={430} max={1.18}>
        <Shop />
        <Mak talking={false} pose={mPose} holdL={writing ? <BookProp /> : null} holdR={writing ? <PenProp /> : null} expr={writing ? 'happy' : 'neutral'} />
        <Character who="tanvir" x={TX} bag watch expr={inR(t, 93.38, 95.3) ? 'happy' : 'neutral'} talking={inR(t, 95.32, 101)} pose={tPose} holdL={holdL} tremble={inR(t, 93.4, 95.3) ? 3 : 0} />
        <Say d={D.d6} x={TX} y={200} dx={330} w={900} size={48} />
      </Camera>
      <At a={89.7} b={93.3} x={1180} y={470} s={170} float><Ic.Book s={170} /></At>
      <At a={96.4} b={101} x={900} y={420} s={170} float><Ic.Phone s={170} /></At>
    </Fill>
  );
};

// ───────── দৃশ্য ৬: মোশন গ্রাফিক্স — চাচার কথা (১০৪.২–১২৩.৪) ─────────
export const S6: React.FC = () => {
  const t = useT();
  return (
    <Fill>
      <MGBg c1="#FFF3DC" c2="#F2D9A8" />
      <Pill a={104.5} b={123.4} text="চাচা মকবুল বললেন" color="#F9C74F" x={60} y={50} />
      <Show a={105.78} b={123.4} style={{left: 210, top: 190}}>
        <Card w={1500} h={640}>
          {inR(t, 105.78, 109.45) && (<><Ic.Sheet s={230} /><div style={text(76)}>জীবনটা তো এক্সেলের শিট না।</div></>)}
          {inR(t, 109.48, 114.2) && (
            <>
              <div style={text(54)}>টাকার অঙ্ক মেলে, কিন্তু মানুষের মুখের হাসি মেলে না।</div>
              <div style={{display: 'flex', gap: 90, alignItems: 'center', marginTop: 10}}>
                <div style={{display: 'flex', gap: 16, alignItems: 'center'}}><Ic.Coin s={150} /><Ic.Check s={90} /></div>
                <div style={{display: 'flex', gap: 16, alignItems: 'center'}}><Ic.Smile s={150} /><Ic.Cross s={90} /></div>
              </div>
            </>
          )}
          {inR(t, 114.22, 121.6) && (
            <>
              <div style={text(58)}>কার চোখে কষ্ট, কার মুখে আনন্দ</div>
              <div style={{display: 'flex', gap: 60, alignItems: 'center'}}>
                <Ic.Smile s={150} mood="sad" /><div style={{position: 'relative'}}><Ic.Monitor s={190} />{t > 119.3 && <div style={{position: 'absolute', right: -20, top: -20}}><Ic.Cross s={90} /></div>}</div><Ic.Smile s={150} />
              </div>
              <div style={text(58, '#DC2626')}>স্ক্রিনে দেখা যায় না।</div>
            </>
          )}
          {inR(t, 121.64, 123.4) && (<><Ic.Eye s={230} /><div style={text(78)}>সামনাসামনি দেখতে হয়।</div></>)}
        </Card>
      </Show>
      <Show a={114.22} b={116.6} style={{left: 1380, top: 150, transform: 'rotate(-8deg)'}}>
        <div style={{background: '#EF4444', color: '#fff', border: '6px solid #222', borderRadius: 20, padding: '8px 36px', ...text(70)}}>৪০ বছর</div>
      </Show>
    </Fill>
  );
};

// ───────── দৃশ্য ৭: মায়ের মিসড কল → ফুটপাথে ফোন (১২৩.৪–১৫৫.০) ─────────
export const S7: React.FC = () => {
  const t = useT();
  const shop = t < 148.3;
  const k = ramp(t, [127.5, 128.2, 130.6, 131.2], [0, 1, 1, 0]);
  const mouth = inR(t, 127.8, 128.6) ? 1 : inR(t, 129.4, 130.0) ? 1 : 0;
  let pose: Pose = IDLE, holdL: React.ReactNode = null;
  if (inR(t, 130.88, 135)) { pose = {l: [35, 115], r: IDLE.r}; holdL = <PhoneProp />; }
  if (inR(t, 144.95, 148.3)) pose = {l: IDLE.l, r: [25, 150]};
  const lx = ramp(t, [138.3, 141], [850, 545]);
  const ly = ramp(t, [138.3, 141], [430, 660]);
  const ls = ramp(t, [138.3, 141], [190, 60]);
  return (
    <Fill>
      {shop ? (
        <>
          <Camera k={k} ox={TX} oy={400} max={1.35}>
            <Shop />
            <Mak talking={inR(t, 123.46, 127.8)} expr={t < 128 ? 'happy' : 'neutral'} />
            <Character who="tanvir" x={TX} bag watch expr={inR(t, 127.8, 128.6) ? 'surprised' : t > 135 && t < 138.2 ? 'think' : t > 144.9 ? 'think' : 'sad'} mouth={mouth} pose={pose} holdL={holdL} tremble={inR(t, 127.8, 131) ? 2.5 : 0} look={0} />
            <Say d={D.d8} x={MX} y={280} dx={-330} w={800} />
          </Camera>
          <At a={130.88} b={135} x={900} y={420} s={210} float><Ic.Phone s={210} missed /></At>
          <Thought a={135} b={138.2} x={TX} y={200}><Ic.Calendar s={110} /><Ic.Question s={110} /></Thought>
          <At a={138.22} b={141.4} x={lx} y={ly} s={ls}><Ic.Laptop s={ls} /></At>
          <At a={141.44} b={144.9} x={900} y={420} s={200} float><Ic.Mail s={200} /></At>
          <At a={142.44} b={144.9} x={990} y={340} s={100}><Ic.Cross s={100} /></At>
          <At a={144.95} b={148.3} x={900} y={420} s={200} float><Ic.Bulb s={200} /></At>
          <Pill a={123.6} b={127.5} text="দোকান • সন্ধ্যা" color="#A5D8F0" />
        </>
      ) : (
        <>
          <Street dusk scroll={0} t={t} />
          <Character who="tanvir" x={700} bag watch expr="happy" talking={inR(t, 150.26, 155)} pose={{l: IDLE.l, r: [25, 150]}} holdR={<PhoneProp />} />
          <Say d={D.d9} x={700} y={200} dx={330} w={900} />
          <Pill a={148.4} b={152} text="ফুটপাথ • সন্ধ্যা" color="#F6B58A" />
          <At a={151.0} b={155} x={1120} y={430} s={170} float><Ic.Heart s={170} /></At>
          <At a={153.48} b={155} x={1340} y={520} s={170} float><Ic.Cup s={170} /></At>
        </>
      )}
    </Fill>
  );
};

// ───────── দৃশ্য ৮: মোশন গ্রাফিক্স — শিক্ষা (১৫৫.০–১৭০) ─────────
export const S8: React.FC = () => {
  const t = useT();
  const th = ramp(t, [162.6, 164.2, 165.88, 167.6], [0, -5, -3, 13]) * Math.PI / 180;
  const cx = 960, cy = 470, R = 400, hang = 190;
  const lx = cx - R * Math.cos(th), ly = cy - R * Math.sin(th);
  const rx = cx + R * Math.cos(th), ry = cy + R * Math.sin(th);
  const W = '#fff', Y = '#FFC83D';
  return (
    <Fill>
      <MGBg c1="#26365F" c2="#0D1530" />
      {/* কার্ড ১: হারানো সন্ধ্যা → ইনক্রিমেন্ট ফেরত দেয় না */}
      <Show a={155.0} b={162.5} anim="up" style={{left: 0, width: 1920, top: 110, textAlign: 'center', ...text(64, W)}}>প্রমোশনের হিসাব কষতে গিয়ে <span style={{color: Y}}>খরচ করে ফেলা সন্ধ্যাগুলো</span></Show>
      <Show a={157.82} b={162.5} style={{left: 250, top: 330}}><Card w={520} h={460}><Ic.Clock s={190} angle={t * 150} /><div style={text(54)}>হারানো সন্ধ্যা</div></Card></Show>
      <At a={159.72} b={162.5} x={960} y={560} s={150} anim="slide"><Ic.Arrow s={150} color="#FFC83D" /></At>
      <Show a={160.7} b={162.5} style={{left: 1150, top: 330}}><Card w={520} h={460}><Ic.Chart s={190} /><div style={text(50)}>ইনক্রিমেন্ট ফেরত দেয় না</div></Card>
        <Show a={161.5} b={162.5} style={{right: -40, top: -50}}><Ic.Cross s={130} /></Show></Show>
      {/* কার্ড ২: দাঁড়িপাল্লা */}
      <Show a={162.52} b={170} anim="up" style={{left: 0, width: 1920, top: 100, textAlign: 'center', ...text(62, W)}}>মায়ের হাতের এক কাপ চায়ের হিসাব<br /><span style={{color: Y}}>কোনো অ্যাপে ধরা পড়ে না</span></Show>
      <Show a={162.6} b={170} anim="fade" style={{left: 0, top: 0, width: 1920, height: 1080}}>
        <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0}}>
          <g stroke="#222" strokeWidth={4} strokeLinejoin="round">
            <rect x={940} y={cy} width={40} height={430} fill="#CBD5E1" /><rect x={820} y={880} width={280} height={40} rx={10} fill="#94A3B8" />
            <line x1={lx} y1={ly} x2={rx} y2={ry} stroke={Y} strokeWidth={14} strokeLinecap="round" />
            <circle cx={cx} cy={cy} r={20} fill={Y} />
            {[[lx, ly], [rx, ry]].map(([x, y], i) => (
              <g key={i}><line x1={x} y1={y} x2={x} y2={y + hang} stroke="#CBD5E1" strokeWidth={5} /><ellipse cx={x} cy={y + hang} rx={160} ry={26} fill="#E2E8F0" /></g>
            ))}
          </g>
        </svg>
        <div style={{position: 'absolute', left: lx - 90, top: ly + hang - 170}}><Ic.Book s={180} /></div>
        <div style={{position: 'absolute', left: rx - 90, top: ry + hang - 170}}><Ic.Cup s={180} /></div>
      </Show>
      <At a={165.9} b={170} x={rx + 120} y={ry + 40} s={110} float><Ic.Heart s={110} /></At>
      <At a={168.48} b={170} x={1650} y={520} s={150} float><div style={{position: 'relative'}}><Ic.Phone s={150} /><div style={{position: 'absolute', right: -20, top: -10}}><Ic.Cross s={70} /></div></div></At>
    </Fill>
  );
};
