import {createContext, useContext} from 'react';
import {useCurrentFrame, interpolate, spring} from 'remotion';
import {FPS, sec} from './data';

// প্রতিটি সিনের শুরু-ফ্রেম; এর সাহায্যে সবকিছু "গ্লোবাল সেকেন্ডে" লেখা যায়
export const StartCtx = createContext(0);
export const useG = () => useCurrentFrame() + useContext(StartCtx);
export const useT = () => useG() / FPS;
export const ramp = (t: number, pts: number[], vals: number[]) =>
  interpolate(t, pts, vals, {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
export const inR = (t: number, a: number, b: number) => t >= a && t < b;

export const usePop = (a: number, b: number) => {
  const g = useG();
  const A = sec(a), B = sec(b);
  const k = spring({frame: Math.max(0, g - A), fps: FPS, config: {damping: 12, stiffness: 150}});
  const o = Math.min(ramp(g, [B - 6, B], [1, 0]), ramp(g, [A, A + 4], [0, 1]));
  return {vis: g >= A && g < B, k, o, g};
};
